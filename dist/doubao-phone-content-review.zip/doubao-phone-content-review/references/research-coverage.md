# 研究来源与覆盖边界

## 2026-11-09增量覆盖

全量分页核对甲方表114条已发布记录（rev4037，1页，has_more=false），及114份当前文档／280条批注卡与可读回复。31条新记录的36条批注卡、当前文字与选取历史文字已学习；83条旧记录中1条新增视频附件、1条仅图片alt描述变化、81条正文和批注指纹未变。即82条旧记录无实质变化，不重复下载其视频。

33个相关文档的历史目录共219条，读取87个选取历史快照，并非219条全读。31条新记录有49份视频附件索引，**本轮没有完成任何新增／变更视频的连续画面＋原声核验**。31条新记录和一只小璐新附件均记partial；历史83条原有“抽帧／ASR非完整听看”限制继续保留。

实际打开卡布原始发布链接，取得可见评论和局部01:16／02:31画面；未听看全片，未确认公开片与稿件附件同版。另30条新记录公开页本轮未打开。没有全量账号近10条基线，不新增数据好case或复投名单。

同时全量检查玩法表98条（rev1857，1页，has_more=false）；机构BF、达人BF、红线、四波BF、小程序专项、玩法参考、会议文字和复盘／执行说明重新读取。项目及周度目录与相关规范／测试子目录完成返回分页；未声称递归读遍所有稿件文件夹或重新听完整会议录音。

实际查看红线开头分类图1张、第四波图片9张，hash已登记。第四波3份内嵌视频及外部拍法例片尚待完整听看；图中的参数询问、分类数字、行程路线仅按可见事实学习，不当成功运行证明。能力限制来自现行BF及测试文字，不冒充本轮亲自操机实测。

证据索引见`learning-state.json`，变更说明见仓库`updates/2026-11-09.md`。原始文件仍在仓库外的学习缓存；可分发包只含知识、来源和核验范围，不含凭证、原始大视频。

## 2026-11-04历史基线（下列数量不代表本周新增）

快照日期2026-11-04；83位达人，244条评论卡（包含解决状态及可读取回复），407个选取历史快照，83份当前视频候选，9份额外附件，21个公开页（其中20个取得可见评论样本）。

| 来源 | 作用 |
|---|---|
| [项目资料文件夹](https://zqyd2vqyqmy.feishu.cn/drive/folder/WWfZf4GSyljdGsdnfzZctHWpnYe) | 列目录并选读相关规范、Brief、会议与流程，不声称读遍所有文件 |
| [每周Brief文件夹](https://zqyd2vqyqmy.feishu.cn/drive/folder/HQi9fAPWTljjE1doWsDceJTanqg) | 每次新审稿先查当周文件 |
| [甲方已发布表](https://zqyd2vqyqmy.feishu.cn/base/Ywpib0LB4anrC3sZI0McgJ00n6f?table=tblS7VpJMd2uS8tl&view=vewXIamkSO) | 按执行进度已发布获取83条，保留原始链接与指标 |
| [玩法测试表](https://zqyd2vqyqmy.feishu.cn/base/Lw5FbEVziaEfoysgqZlc3r81nbc?table=tblInpg2tLlt0JKg) | 98条记录，状态、结果、失败环节、是否可推分别读取 |
| [机构版Brief](https://zqyd2vqyqmy.feishu.cn/docx/P4cAdKXRJo6mZ1xE0yXcCp50nA3) | 三类达人与合作内容基线 |
| [达人版Brief](https://zqyd2vqyqmy.feishu.cn/docx/LOggdkMujokCnyxwdH9cKS0hnTd) | 达人理解与拍摄参考 |
| [机构红线规范](https://zqyd2vqyqmy.feishu.cn/docx/AAIkdB4w3oBRLAx8g16cq30pnBd) | 项目要求，不冒称抖音官方规则 |
| [第一波Brief](https://zqyd2vqyqmy.feishu.cn/docx/IzqjdROsoolPOlxKhTlc0MApngg) | 历史适用场景 |
| [第二波Brief](https://zqyd2vqyqmy.feishu.cn/docx/PJZ8dye1xoMjiVxiohQcHbeRnsc) | 历史适用场景 |
| [第三波Brief](https://zqyd2vqyqmy.feishu.cn/docx/R9hldOt4moxH7ZxfT0Ict00mn4c) | 文件与表格波次日期口径不一，按本次任务确认 |
| [第四波Brief11.9-11.15](https://zqyd2vqyqmy.feishu.cn/docx/CY1PdyULzoUy9Lx2S9hc5jYlnQd) | 11月4日时为后续一波，优先本机与读屏 |
| [小程序专项Brief](https://zqyd2vqyqmy.feishu.cn/docx/BVoYdo8XWoKuR4xvCEQcZjhingh) | 专项30秒以内、问答和服务连续衔接 |
| [玩法参考](https://zqyd2vqyqmy.feishu.cn/docx/MfcxdBCEGoRvrAxdbxIchbtynOd) | 与实时测试状态冲突时不机械沿用 |
| [10月30日会议原始文字](https://zqyd2vqyqmy.feishu.cn/docx/G4bhdapTsoW8jVx5Ac3czMdJnHj) | 支持保留原生表达、删泛赞、补具体结果；说话人需原始证据归属 |
| [11月4日AI会议纪要](https://zqyd2vqyqmy.feishu.cn/docx/QjkidxB7VowMG7xeBoichslinqc) | 含姓名/判断矛盾，仅作线索，不独立决定复投或淘汰 |
| [项目流程](https://zqyd2vqyqmy.feishu.cn/docx/AXfJdHJ44otOMMxCS9scoXgtn3d) | 供理解初审与甲方确认分工，不扩展业务写入授权 |

## 哪些结论属于谁

- 明确项目要求：来源文件或甲方批注明文提出；保留日期、阶段、例外。
- 实际观察：本轮看到的脚本文字、视频帧、可见评论和数据。
- 审核建议：对以上证据作出的改法与测试方案，不冒充甲方已经决定。
- 待验证：新玩法、缺少连续过程/声音、发布版本不同、统计口径不明等。

## 没有假装完成的部分

- 948条历史记录中选取407个快照，并非逐个下载每次自动保存；重点覆盖最早内容及批注前后，比较差异并核对最新稿。
- 161个视频附件已建立索引；实际用于画面检查92份，其中83份为每位达人当前文档首附件候选，9份为历史/操作证据。其余未逐份复看。
- 视频核验方法是15点抽帧与全音轨机器转写辅助；转写可能失败。未把它写成人工从头到尾观看全部视频。
- 21个公开页真实打开，其中20条取得可见评论样本、C029未加载评论；另62条公开评论没有核验。没有全量评论真实性鉴定。
- 未对83个账号完成近期主页全量审查，因此画像建议不是正式达人名单。
- 不掌握完整投流、留存、转化和账号常态基线，不能证明某种拍法带来了增长。
- 客户表、机构表、审批状态、群消息均未修改；研究产物为本地文档和审稿skill。

## 本地证据如何回查

`analysis/cases.json` 保存83条原链接和表内指标；`analysis/text/Cxxx.txt` 是最新脚本与批注文本；`analysis/revision-diffs/` 是选取快照的差异；`analysis/video/Cxxx-vN/` 是时间点、抽帧和机器转写；`raw/media/` 为对应附件。完整证据保留在本次工作目录，分享包不包含大体积视频与模型。

外发请优先只转发《给达人看的拍摄说明》。内部案例包含客户沟通与达人表现点评，不应整包直接发给所有机构。
